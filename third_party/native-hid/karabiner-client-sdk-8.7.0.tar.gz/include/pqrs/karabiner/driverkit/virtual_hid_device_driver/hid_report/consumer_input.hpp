#pragma once

// (C) Copyright Takayama Fumihiko 2020.
// Distributed under the Boost Software License, Version 1.0.
// (See https://www.boost.org/LICENSE_1_0.txt)

#include "keys.hpp"
#include <cstdint>
#include <cstring>

namespace pqrs::karabiner::driverkit::virtual_hid_device_driver::hid_report {

class __attribute__((packed)) consumer_input final {
public:
  consumer_input() = default;
  bool operator==(const consumer_input& other) const { return (memcmp(this, &other, sizeof(*this)) == 0); }
  bool operator!=(const consumer_input& other) const { return !(*this == other); }

private:
  uint8_t report_id_ __attribute__((unused)){2};

public:
  keys keys;
};
} // namespace pqrs::karabiner::driverkit::virtual_hid_device_driver::hid_report
